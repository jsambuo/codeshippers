//
//  ViewController.swift
//  Counter
//
//  Created by Sambuo, Jimmy on 10/2/17.
//  Copyright © 2017 Sambuo, Jimmy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var count = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        displayLabel.text = "Tapped \(count) times"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBOutlet weak var displayLabel: UILabel!
    @IBAction func buttonTapped(_ sender: Any) {
        count = count + 1
        displayLabel.text = "Tapped \(count) times"
    }
    
}

